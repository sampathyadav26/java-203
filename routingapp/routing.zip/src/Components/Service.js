import React from 'react'

function Service() {
  return (
    <div>
      <h2>Service</h2>
      <p>What Services you want</p>
    </div>
  )
}

export default Service
