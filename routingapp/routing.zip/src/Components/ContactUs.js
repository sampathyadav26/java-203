import React from 'react'

function ContactUs() {
  return (
    <div>
      <h2>Contact</h2>

      
    </div>
  )
}

export default ContactUs
