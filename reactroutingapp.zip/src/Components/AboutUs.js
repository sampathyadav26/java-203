import React from 'react'

function AboutUs() {
  return (
    <div>
      <h1>AboutUs Components</h1>
    </div>
  )
}

export default AboutUs
