import React from 'react'

function Service() {
  return (
    <div>
      <h1>Services Component</h1>
    </div>
  )
}

export default Service
