import { initializeApp } from "firebase/app";
import {getFirestore} from "@firebase/firestore";
import 'firebase/compat/firestore';
const firebaseConfig = {
    apiKey: "AIzaSyCjqyrMcLD7e0FblCOW3LHJti2tyzW5umg",
    authDomain: "fbdemo-4cabb.firebaseapp.com",
    projectId: "fbdemo-4cabb",
    storageBucket: "fbdemo-4cabb.appspot.com",
    messagingSenderId: "1045128798799",
    appId: "1:1045128798799:web:14d19bf16c55512f7dc03a"
  };
  
  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  export  const db=getFirestore(app);



