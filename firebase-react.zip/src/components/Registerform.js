import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import StoreServices from "../services/StoreServices";

function Create() {
  const [id, setid] = useState();
  const [username, setUserName] = useState();
  const [useremail, setUserEmail] = useState();
  const [password, setPassword] = useState();
  const [phoneno, setPhoneno] = useState();
  const [city, setCity] = useState();
  const navigate = useNavigate();
  const CreateStore = (e) => {
    let data = {
      id: parseInt(id),
      username: username,
      useremail: useremail,
      password: password,
      phoneno: phoneno,
      city: city,
    };
    //alert(JSON.stringify(data));
    StoreServices.createStore(data).then((res) => {});
    navigate("/Login");
  };
  return (
    <div>
      <form action="/action_page.php">
        <div className="container" style={{width:"900px"}}>
          <h1 style={{textAlign:"center"}}>Registeration From</h1>
          <hr />
          <label for="id">
            <b>User Id</b>
          </label>
          <input
            type="text"
            placeholder="Enter User Id"
            name="id"
            id="id"
            value={id}
            onChange={(e) => setid(e.target.value)}
            required
            className=" mb-0"
          />

          <label for="username">
            <b>User Name</b>
          </label>
          <input
            type="text"
            placeholder="Enter Name"
            name="username"
            id="username"
            value={username}
            onChange={(e) => setUserName(e.target.value)}
            required
            className="mb-0 className"
          />

          <label for="email">
            <b>Email</b>
          </label>
          <input
            type="text"
            placeholder="Enter Email"
            name="email"
            id="email"
            value={useremail}
            onChange={(e) => setUserEmail(e.target.value)}
            required
            className="mb-0 "
          ></input>

          <label for="psw">
            <b>Password</b>
          </label>
          <input
            type="password"
            placeholder="Enter Password"
            name="psw"
            id="psw"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="mb-0 "
          />

          <label for="phoneno">
            <b>Phone No</b>
          </label>
          <input
            type="text"
            placeholder="Enter phone"
            name="phoneno"
            id="phoneno"
            value={phoneno}
            onChange={(e) => setPhoneno(e.target.value)}
            required
            className="mb-0"
          ></input>

          <label for="city">
            <b>City</b>
          </label>
          <input
            type="text"
            placeholder="Enter city"
            name="city"
            id="city"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            required
            className="mb-0 "
          ></input>
        </div>
          <center><button type="submit" className="registerbtn" onClick={CreateStore}>
            Register
          </button></center>
      </form>
    </div>
  );
}

export default Create;