import { useState } from "react";
import { collection, addDoc } from "firebase/firestore";

import {db} from "../firebase.config";
function Add(){
    const[uid,setUid]=useState();
    const[name,setName]=useState();
    const[price,setPrice]=useState();
    const boardsCollectionRef = collection(db, "boards");

    const addId = (e) => {
      e.preventDefault();
      addDoc(boardsCollectionRef, {
        uid,
        name,
        price,
      });
    };
    return (
      <div>
        <div className="container">
          <div className="card">
            <div className="card-header">
              <h1> Enter the Board details</h1>
            </div>
            <form>
              <div class="mb-3 mt-3">
                <label for="uid" class="form-label">
                  Uid
                </label>
                <input
                  type="uid"
                  class="form-control"
                  id="id"
                  placeholder="Enter id"
                  name="uid"
                  onChange={(e) => {
                    setUid(e.target.value);
                  }}
                />
              </div>
              <div class="mb-3">
                <label for="name" class="form-label">
                Name
                </label>
                <input
                  type="name"
                  class="form-control"
                  id="name"
                  placeholder="Enter name"
                  name="name"
                  onChange={(e) => {
                    setName(e.target.value);
                  }}
                />
              </div>
              <div class="mb-3 mt-3">
                <label for="price" class="form-label">
                Price
                </label>
                <input
                  type="price"
                  class="form-control"
                  id="price"
                  placeholder="Enter price"
                  name="price"
                  onChange={(e) => {
                    setPrice(e.target.value);
                  }}
                />
              </div>
              
            </form>
          </div><br/>
          <center>
                <button
                  type="submit"
                  class="btn btn-primary"
                  id="button"
                  onClick={addId}
                >
                  Submit
                </button>
              </center>
        </div>
      </div>
    );
  }
  
  export default Add;