import React from "react";
import { useState, useEffect } from "react";
import { db } from "../firebase.config";
import { collection, deleteDoc, doc, getDocs } from "firebase/firestore";
import {useNavigate} from 'react-router-dom';

function View() {
  const [boards, setBoards] = useState([]);
  const boardsCollectionRef = collection(db, "boards");
  const navigate=useNavigate();

  const getBoards = async () => {
    const data = await getDocs(boardsCollectionRef);
    setBoards(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
  };
  useEffect(() => {
    getBoards();
  }, []);
  const DeleteBoard= async(id)=>{
const boardDoc=doc(db, "boards" ,id);
await deleteDoc(boardDoc);
getBoards();
navigate("/view");

  };

  return (

    <div className="container">
      <div className="card">
        <div>
          <div className="card-header" >
            <h1 style={{folat:"center"}}>Board List</h1>
          </div>
          <table className="table">
            <thead>
              <tr>
           
                <th scope="col">Uid</th>
                <th scope="col">Name</th>
                <th scope="col">Price</th>
                <th colSpan={2}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {boards.map((board) => {
                return (
                  <tr key={board.id}>
                    <td>{board.uid}</td>
                    <td>{board.name}</td>
                    <td>{board.price}</td>
                    <td>
                      <a className="btn btn-primary" style={{ margin: "10px" }}>
                        View
                      </a>
                      <a className="btn btn-primary" style={{ margin: "10px" }}>
                        Edit
                      </a>
                      <button className="btn btn-danger" onClick={() => DeleteBoard(board.id)}>Delete</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default View;
// onClick={() => viewProduct(product.id)}
// onClick={() => updateProduct(product.id)}
// onClick={() => deleteData(product.id)}