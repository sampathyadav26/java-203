import React, { useState } from "react";
import { useNavigate } from "react-router-dom";


function Login() {

    const [name, setName] = useState('');

    const [password, setPassword] = useState('');

    const navigate = useNavigate();

    let login = (e) => {

        e.preventDefault();

        if (name === password) {

            navigate("/view");

        }

        else {
            alert("invalid");
        }
    }
    return (
        <div className="container">
            <h1>login page</h1>
            <form>
                <div class="mb-3">
                    <label for="exampleInputUserName" class="form-label">User Name</label>
                    <input type="text" class="form-control" id="exampleInputUserName" onChange={(e) => setName(e.target.value)} />
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" onChange={(e) => setPassword(e.target.value)} />
                </div>

                <button type="submit" class="btn btn-primary" onClick={login}>Login</button>
            </form>
            {name}
            {password}
        </div>
    )
}

export default Login

