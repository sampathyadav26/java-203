import { BrowserRouter,Routes,Route,Link } from 'react-router-dom';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Add from "./components/Add";
import View from "./components/View"; 
import Login from "./components/Login";


function App() {
  return (
    <div className="App">
      <BrowserRouter>
      
      <div >
      <ul>
        
      <li><Link to="/login" className="btn btn-primary">SigIn</Link></li>
        <li><Link to ="/add" className="btn btn-primary">Add</Link></li>
        <li><Link to ="/view" className="btn btn-primary">Show</Link></li>
      </ul>
      </div>
    <Routes>
    <Route path="/Login" element={<Login/>} />
      <Route path="/add" element={<Add/>}/>
      <Route path="/view" element={<View/>}/>
    </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;
