import React from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
// import SignInSignUp from "./components/navbar/SignInSignUp";
import NavBar from "./components/navbar/NavBar";

const App = () => {
  return (
    <div>
      {/* <SignInSignUp /> */}
      <NavBar />
    </div>
  );
};

export default App;
