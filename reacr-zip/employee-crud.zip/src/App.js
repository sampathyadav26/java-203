
import './App.css';

function App() {
  return (
    <div className="App">
<EmployeeList/>
    </div>
  );
}

export default App;
