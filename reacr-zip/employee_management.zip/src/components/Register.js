import React from 'react'

function Register() {
  return (
    <div>
      <h1>hi</h1>
    </div>
  )
}

export default Register
