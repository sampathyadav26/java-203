import React from 'react'

function UpdateStudent() {

//     const updatestd = async () => {
//         await StudentService.UpdateStudent(id,student).then((res)=>{
//            console.log("Student list is:" + JSON.stringify(res.data));
//         }) 
//    }

  return (
    <div>
      <h2>UpdateStudent</h2>
    </div>
  )
}

export default UpdateStudent
