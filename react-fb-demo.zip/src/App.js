
import './App.css';
import { useState,useEffect } from 'react';
import Create from './components/Create';
import firebase from './firebase';

import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';
import { doc, getDocs } from 'firebase/firestore';
function App() {
  const[boards, setboards]=useState([]);
  const userCollectionRef=collection(db, "users")
  useEffect(()=>{
const getUsers=async()=>{
const data=await getDocs(userCollectionRef);
setUsers(data.docs.map(doc)=)
}
  }, [])
  return (
    <div className="App">
<Create/>
    </div>
  );
}

export default App;
