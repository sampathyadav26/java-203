import React from 'react'

function Submodule() {
  return (
    <div>
      <h1>Hurray from functional sub module</h1>
    </div>
  )
}

export default Submodule
