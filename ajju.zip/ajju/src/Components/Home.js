import React, { Component } from 'react'

export class Home extends Component {
  render() {
        let arr = ["abc","pqr","xyz"];
         function hello(e){
            e.preventDefault();
          // document.write("wekljljgyh00");
          console.table(arr);
        }
       
      
    return (
      <div>
        <h1>hi from home Component</h1>
        <button onClick={hello}>submit</button>
      </div>
      
    )
  }
}

export default Home
