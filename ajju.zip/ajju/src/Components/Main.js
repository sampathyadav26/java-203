import React, { Component } from 'react'

export class Main extends Component {
  render() {
    return (
      <div>
        <h1>hello from main component</h1>
      </div>
    )
  }
}

export default Main
