import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import UsersList from './components/UsersList';
function App() {
  return (
    <div className="App">
      <UsersList />
    </div>
  );
}

export default App;
