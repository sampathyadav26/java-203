import React from 'react'

function SubComponent1() {
  return (
    <div>
      <h1>functional subcomponent</h1>
    </div>
  )
}

export default SubComponent1
