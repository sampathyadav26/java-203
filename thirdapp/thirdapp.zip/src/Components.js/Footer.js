import React, { Component } from 'react'

export class Footer extends Component {
  render() {
    return (
      <div>
        <h1>welcome to reactjs FooterCompenent</h1>
      </div>
    )
  }
}

export default Footer
