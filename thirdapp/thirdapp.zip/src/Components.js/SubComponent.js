import React, { Component } from 'react'

export class SubComponent extends Component {
  render() {
    return (
      <div>
        <h1>child Component</h1>
      </div>
    )
  }
}

export default SubComponent
