import React, { Component } from 'react'

export class MainComponent extends Component {
  render() {
    return (
      <div>
        <h1> welcome to reactjs maincomponent </h1>
      </div>
    )
  }
}

export default MainComponent
