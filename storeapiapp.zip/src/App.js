
import './App.css';
import Api from './components/Api';
import Home from './components/Home';

import NavBar from './components/NavBar';
function App() {
  return (
    <div className="App">
        
        <NavBar /> 
        <Home/>
        {/* <Api/> */}
      
    </div>
  );
}

export default App;
