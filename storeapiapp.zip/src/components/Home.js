import React from 'react'

function Home() {
    return (
        <body className="Body">
            <h1>Home Page</h1>
            <img src="https://miro.medium.com/max/1400/0*v1b5Jjag7e4SQRw7"></img>
        </body>
    )
}

export default Home
