import React from 'react'

function Footer() {
    return (
        <div>
            <center><h5>All Copy Rights &copy; Reservered By 2021 Ojas Batch</h5></center>
        </div>
    )
}

export default Footer
