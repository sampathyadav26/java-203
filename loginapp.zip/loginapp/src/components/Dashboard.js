function Dashboard() {



    let employees = [
       {
         "empid":22106,
         "empname":"Preethi ",
         "domain":"java",
         "status":"sustu",
       },
       {
         "empid":22104,
         "empname":"chandana",
         "domain":"java",
         "status":"deployed",
       },
       {
        "empid":22102,
        "empname":"harish",
        "domain":"java",
        "status":"deployed",
       },
   
   
   
    ];
     const employeeList = employees.map( employee =>{
       return(
         <tr key={employee.id}>
           <td>{employee.empid}</td>
           <td>{employee.empname}</td>
           <td>{employee.domain}</td>
           <td>{employee.status}</td>
           <td>
             <button className='btn btn-primary' style={{margin:"10px"}}>Edit</button>
             <button className='btn btn-danger'>update</button>
           </td>
         </tr>
       )
     })
     return (
      
       <div>
         {console.log(employees)}
         <h1>employees List</h1>
         <hr/>
         <table class="table">
     <thead>
       <tr>
         <th scope="col">EmpId</th>
         <th scope="col">EmpName</th>
         <th scope="col">Domain</th>
         <th scope="col">Status</th>
         <th colSpan={"2"}>Actions</th>
       </tr>
     </thead>
     <tbody>
     {employeeList}
     </tbody>
   </table>
       </div>
     )
   }
   
   
   
   export default Dashboard