import React, { useState } from "react";
import { useNavigate } from "react-router-dom";



function Register() {
    const [name, setName] = useState("");
    const [personalname, setPersonalname] = useState("");
    const [mobilenum,  setMobilenum] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();
    let regis = (e) => {
      e.preventDefault();
      if(name!="")
      {
        alert(name +" sucessfully registered");
      }
      else{
        alert("please give the correct details");
      }
    };
    
    return (
        <div className='container'>
            <h1>Register Application</h1>
            <form>
                <div class="mb-3">
                    <label for="exampleInputEmpName" class="form-label">Employee Name</label>
                    <input type="text" 
                    class="form-control" 
                    id="exampleInputEmail1"
                    onChange={(e) => setName(e.target.value)}   
                     />
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Personal Email address</label>
                    <input type="email" 
                    class="form-control" 
                    id="exampleInputEmail1"
                    onChange={(e) => setPersonalname(e.target.value)}
                     />
                    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                </div>
                <div class="mb-3">
                    <label for="exampleInputMobile" class="form-label">Mobiel Num</label>
                    <input type="text"
                     class="form-control"
                      id="exampleInputMobile"
                      onChange={(e) => setMobilenum(e.target.value)}  />
                </div>

                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" 
                    class="form-control" 
                    id="exampleInputPassword1" 
                    onChange={(e) => setPassword(e.target.value)}/>
                </div>
                
                <button type="submit" class="btn btn-primary" onClick={regis}>SignUp</button>
            </form>

        </div>
    )
}

export default Register
